package academy.learnprogramming.accessmodifiers

fun main(args: Array<String>) {

    val emp = Employee()
    println(emp)

}

private class Employee {

}


