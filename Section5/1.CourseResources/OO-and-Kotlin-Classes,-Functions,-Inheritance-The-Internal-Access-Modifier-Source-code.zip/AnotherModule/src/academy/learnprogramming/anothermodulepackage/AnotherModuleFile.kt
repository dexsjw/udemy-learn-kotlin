package academy.learnprogramming.anothermodulepackage

import academy.learnprogramming.communications.topLevel
import academy.learnprogramming.communications.upperFirstAndLast


fun main(args: Array<String>) {
    topLevel("Hello from another module")
    println("a string to work with".upperFirstAndLast())
    
}