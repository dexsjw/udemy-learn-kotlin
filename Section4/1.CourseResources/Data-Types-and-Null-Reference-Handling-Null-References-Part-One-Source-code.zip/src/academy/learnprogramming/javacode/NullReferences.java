package academy.learnprogramming.javacode;

public class NullReferences {

    public static void main(String[] args) {
        String str = null;
        str.toUpperCase();


    }

}
