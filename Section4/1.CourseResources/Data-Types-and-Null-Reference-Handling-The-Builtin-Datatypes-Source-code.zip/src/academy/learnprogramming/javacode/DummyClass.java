package academy.learnprogramming.javacode;

public class DummyClass {

    public String isVacationTime(Boolean onVacation) {
        return onVacation ? "I'm on vacation!" : "I'm working";
    }

}
