package academy.learnprogramming.javacode;

public class DummyClass {

    public static void main(String[] args) {
        System.out.println("I'm just here so there's a Java file");
    }

}
