package academy.learnprogramming.helloworld

fun main(args: Array<String>) {
    println("Hello, World!")
}


